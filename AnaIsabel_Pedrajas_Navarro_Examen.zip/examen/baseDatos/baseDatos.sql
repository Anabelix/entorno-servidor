CREATE TABLE Logs (
    id int auto_increment PRIMARY KEY,
    navegador VARCHAR(255),
    timestamp int
);